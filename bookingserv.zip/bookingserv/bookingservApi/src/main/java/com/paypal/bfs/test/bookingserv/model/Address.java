package com.paypal.bfs.test.bookingserv.model;

import com.fasterxml.jackson.annotation.*;

import javax.persistence.Embeddable;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"line1", "line2", "city", "state", "zip_code", "id"})
@Embeddable
public class Address {
    @JsonProperty("line1")
    @JsonPropertyDescription("First Line of address")
    @NotNull
    @Size(min = 4, max = 100)
    private String line1;
    @JsonProperty("line2")
    @JsonPropertyDescription("Second Line of address")
    private String line2;
    @JsonProperty("city")
    @NotNull
    @Size(min = 4, max = 100)
    @JsonPropertyDescription("City of the location")
    private String city;

    @NotNull
    @Size(min = 4, max = 100)
    @JsonProperty("state")
    @JsonPropertyDescription("State of the location")
    private String state;

    @NotNull
    @Min(value = 100000)
    @Max(value = 999999)
    @JsonProperty("zip_code")
    @JsonPropertyDescription("Zip code of the location")
    private Integer zipCode;


    @JsonIgnore
    @Transient
    private Map<String, Object> additionalProperties = new HashMap();

    public Address() {
    }

    @JsonProperty("line1")
    public String getLine1() {
        return this.line1;
    }

    @JsonProperty("line1")
    public Address setLine1(String line1) {
        this.line1 = line1;
        return this;
    }

    @JsonProperty("line2")
    public String getLine2() {
        return this.line2;
    }

    @JsonProperty("line2")
    public Address setLine2(String line2) {
        this.line2 = line2;
        return this;
    }

    @JsonProperty("city")
    public String getCity() {
        return this.city;
    }

    @JsonProperty("city")
    public Address setCity(String city) {
        this.city = city;
        return this;
    }

    @JsonProperty("state")
    public String getState() {
        return this.state;
    }

    @JsonProperty("state")
    public Address setState(String state) {
        this.state = state;
        return this;
    }

    @JsonProperty("zip_code")
    public Integer getZipCode() {
        return this.zipCode;
    }

    @JsonProperty("zip_code")
    public Address setZipCode(Integer zipCode) {
        this.zipCode = zipCode;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public Address setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Address.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("line1");
        sb.append('=');
        sb.append(this.line1 == null ? "<null>" : this.line1);
        sb.append(',');
        sb.append("line2");
        sb.append('=');
        sb.append(this.line2 == null ? "<null>" : this.line2);
        sb.append(',');
        sb.append("city");
        sb.append('=');
        sb.append(this.city == null ? "<null>" : this.city);
        sb.append(',');
        sb.append("state");
        sb.append('=');
        sb.append(this.state == null ? "<null>" : this.state);
        sb.append(',');
        sb.append("zipCode");
        sb.append('=');
        sb.append(this.zipCode == null ? "<null>" : this.zipCode);
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(this.additionalProperties == null ? "<null>" : this.additionalProperties);
        sb.append(',');
        if (sb.charAt(sb.length() - 1) == ',') {
            sb.setCharAt(sb.length() - 1, ']');
        } else {
            sb.append(']');
        }

        return sb.toString();
    }
}
