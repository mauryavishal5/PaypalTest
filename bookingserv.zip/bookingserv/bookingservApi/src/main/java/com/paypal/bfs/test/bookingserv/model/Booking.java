package com.paypal.bfs.test.bookingserv.model;

import com.fasterxml.jackson.annotation.*;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"id", "first_name", "last_name", "date_of_birth", "checkin_datetime", "checkout_datetime", "totalprice", "deposit", "address"})
@Entity
public class Booking {

    @JsonProperty("id")
    @JsonPropertyDescription("Booking id")
    @NotNull(message = "Booking Id is Mandatory")
    @Positive(message = "Booking Id Should be non negative number")
    @Id
    private Integer id;
    @JsonProperty("first_name")
    @JsonPropertyDescription("First name")
    @NotNull(message = "First Name cannot be empty")
    @Size(min = 4,max = 100,message = "First Name should be between 4 to 100 characters")
    private String firstName;
    @JsonProperty("last_name")
    @JsonPropertyDescription("Last name")
    @NotNull(message = "First Name cannot be empty")
    @Size(min = 4,max = 100,message = "Last Name should be between 4 to 100 characters")
    private String lastName;
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd"
    )
    @JsonProperty("date_of_birth")
    @JsonPropertyDescription("Date of birth")
    @NotNull(message = "Date of birth is mandatory.")
    private LocalDate dateOfBirth;
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd HH:mm:ss",
            timezone = "UTC"
    )
    @NotNull(message = "Check-in Date and Time is mandatory")
    @JsonProperty("checkin_datetime")
    @JsonPropertyDescription("Check In Date Time")
    private LocalDateTime checkinDatetime;
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd HH:mm:ss",
            timezone = "UTC"
    )
    @NotNull(message = "Check-out Date and Time is mandatory")
    @JsonProperty("checkout_datetime")
    @JsonPropertyDescription("Check Out Date Time")
    private LocalDateTime checkoutDatetime;
    @JsonProperty("totalprice")
    @JsonPropertyDescription("Total Bill for the duration of stay")
    @NotNull(message = "Price is mandatory")
    private Double totalprice;

    @JsonProperty("deposit")
    @JsonPropertyDescription("Total Bill for the duration of stay")
    @NotNull(message = "Some deposite is required")
    private Double deposit;
    @JsonProperty("address")
    @JsonPropertyDescription("Address resource object")
    @Valid
    @NotNull(groups = { Address.class })
    @Embedded
    private Address address;
    @JsonIgnore
    @Transient
    private Map<String, Object> additionalProperties = new HashMap();

    public Booking() {
    }

    @JsonProperty("id")
    public Integer getId() {
        return this.id;
    }

    @JsonProperty("id")
    public Booking setId(Integer id) {
        this.id = id;
        return this;
    }

    @JsonProperty("first_name")
    public String getFirstName() {
        return this.firstName;
    }

    @JsonProperty("first_name")
    public Booking setFirstName(String firstName) {
        this.firstName = firstName;
        return this;

    }

    @JsonProperty("last_name")
    public String getLastName() {
        return this.lastName;
    }

    @JsonProperty("last_name")
    public Booking setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("date_of_birth")
    public LocalDate getDateOfBirth() {
        return this.dateOfBirth;
    }

    @JsonProperty("date_of_birth")
    public Booking setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        return this;
    }

    @JsonProperty("checkin_datetime")
    public LocalDateTime getCheckinDatetime() {
        return this.checkinDatetime;
    }

    @JsonProperty("checkin_datetime")
    public Booking setCheckinDatetime(LocalDateTime checkinDatetime) {
        this.checkinDatetime = checkinDatetime;
        return this;
    }

    @JsonProperty("checkout_datetime")
    public LocalDateTime getCheckoutDatetime() {
        return this.checkoutDatetime;
    }

    @JsonProperty("checkout_datetime")
    public Booking setCheckoutDatetime(LocalDateTime checkoutDatetime) {
        this.checkoutDatetime = checkoutDatetime;
        return this;
    }

    @JsonProperty("totalprice")
    public Double getTotalprice() {
        return this.totalprice;
    }

    @JsonProperty("totalprice")
    public Booking setTotalprice(Double totalprice) {
        this.totalprice = totalprice;
        return this;
    }

    @JsonProperty("deposit")
    public Double getDeposit() {
        return this.deposit;
    }

    @JsonProperty("deposit")
    public Booking setDeposit(Double deposit) {
        this.deposit = deposit;
        return this;
    }

    @JsonProperty("address")
    public Address getAddress() {
        return this.address;
    }

    @JsonProperty("address")
    public Booking setAddress(Address address) {
        this.address = address;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public Booking setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Booking.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("id");
        sb.append('=');
        sb.append(this.id == null ? "<null>" : this.id);
        sb.append(',');
        sb.append("firstName");
        sb.append('=');
        sb.append(this.firstName == null ? "<null>" : this.firstName);
        sb.append(',');
        sb.append("lastName");
        sb.append('=');
        sb.append(this.lastName == null ? "<null>" : this.lastName);
        sb.append(',');
        sb.append("dateOfBirth");
        sb.append('=');
        sb.append(this.dateOfBirth == null ? "<null>" : this.dateOfBirth);
        sb.append(',');
        sb.append("checkinDatetime");
        sb.append('=');
        sb.append(this.checkinDatetime == null ? "<null>" : this.checkinDatetime);
        sb.append(',');
        sb.append("checkoutDatetime");
        sb.append('=');
        sb.append(this.checkoutDatetime == null ? "<null>" : this.checkoutDatetime);
        sb.append(',');
        sb.append("totalprice");
        sb.append('=');
        sb.append(this.totalprice == null ? "<null>" : this.totalprice);
        sb.append(',');
        sb.append("deposit");
        sb.append('=');
        sb.append(this.deposit == null ? "<null>" : this.deposit);
        sb.append(',');
        sb.append("address");
        sb.append('=');
        sb.append(this.address == null ? "<null>" : this.address);
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(this.additionalProperties == null ? "<null>" : this.additionalProperties);
        sb.append(',');
        if (sb.charAt(sb.length() - 1) == ',') {
            sb.setCharAt(sb.length() - 1, ']');
        } else {
            sb.append(']');
        }

        return sb.toString();
    }
}
