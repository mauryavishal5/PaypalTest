package com.paypal.bfs.test.bookingserv.impl;

import com.paypal.bfs.test.bookingserv.api.BookingResource;
import com.paypal.bfs.test.bookingserv.model.Booking;
import com.paypal.bfs.test.bookingserv.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
public class BookingResourceImpl implements BookingResource {

    @Autowired
    BookingRepository bookingRepository;

    @Override
    public ResponseEntity<Booking> create(Booking booking) {
        Optional<Booking> already  = bookingRepository.findById(booking.getId());
        if (already.isPresent()){
            return new ResponseEntity<>(already.get(), HttpStatus.CONFLICT);
        } else {
            booking = bookingRepository.save(booking);
            return new ResponseEntity<>(booking, HttpStatus.CREATED);
        }
    }

    @Override
    public ResponseEntity<List<Booking>> getAll() {
        Iterable<Booking> bookings = bookingRepository.findAll();
        List<Booking> result = new ArrayList<>();
        bookings.forEach(result::add);
        return new ResponseEntity<>(result,HttpStatus.OK);
    }


}
