package com.paypal.bfs.test.bookingserv.repository;

import com.paypal.bfs.test.bookingserv.model.Address;
import com.paypal.bfs.test.bookingserv.model.Booking;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@DataJpaTest
class BookingRepositoryTest {

    @Autowired
    private BookingRepository bookingRepository;

    private Booking booking;

    @BeforeEach
    public void setUp(){
        booking = getBookingPojo(1);
    }

    @AfterEach
    public void tearDown() {
        bookingRepository.deleteAll();
        booking = null;
    }


    @Test
    public void givenBookingToAddShouldReturnSavedBooking(){
        bookingRepository.save(booking);
        Booking savedBooking = bookingRepository.findById(booking.getId()).get();
        assertEquals(1, savedBooking.getId().intValue());
    }

    @Test
    public void givenGetAllBookingShouldReturnListOfAllBookings(){
        bookingRepository.save(booking);
        Booking booking2 = getBookingPojo(2);
        bookingRepository.save(booking2);


        List<Booking> productList = (List<Booking>) bookingRepository.findAll();
        assertEquals(2, productList.get(1).getId().intValue());
    }


    private Booking getBookingPojo(Integer id){
        Address address = new Address();
        address.setLine1("Sample Address Line 1").setLine1("Sample Address Line 2").setCity("Delhi").setState("Delhi")
                .setZipCode(110001);
        Booking testBook = new Booking();
        testBook.setAddress(address).setFirstName("Vishal").setLastName("Maurya").setId(id)
                .setDateOfBirth(LocalDate.of(1991, Month.APRIL,13))
                .setCheckinDatetime(LocalDateTime.now().minusDays(1))
                .setCheckoutDatetime(LocalDateTime.now().plusDays(1))
                .setDeposit(200d).setTotalprice(1500d);
        return testBook;
    }


}